
from Crypto.Cipher import DES

fh = open("./secret.pdf.enc2", "rb")
text = fh.read()
fh.close()

key = "b042cc94a2ec429a".decode("hex")

cipher = DES.new(key, DES.MODE_ECB)
msg = cipher.decrypt(text)

fh = open("./secret.pdf", "wb")
fh.write(msg)
fh.close()

print(msg[0:8])
