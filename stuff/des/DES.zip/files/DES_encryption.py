
from Crypto.Cipher import DES

fh = open("./test.pdf", "rb")
plaintext = fh.read() + "000000"            # added padding to make plaintext valid
key = b'104\rca25'                          # key
cipher = DES.new(key, DES.MODE_ECB)         # new DES encryption in ECB mode
msg = cipher.encrypt(plaintext[0:16])       # encrypt

fh = open("./test.pdf.enc", "wb")           # save encrypted file
fh.write(msg)
fh.close()

print("ENCRYPTED", str(msg[0:8]), msg[0:8].encode("hex"))
plaintext = cipher.decrypt(msg[0:8])
print("DECRYPTED", str(plaintext), plaintext.encode("hex"))
