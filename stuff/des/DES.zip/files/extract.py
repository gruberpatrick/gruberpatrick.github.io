
fh = open("./tset.pdf", "rb")
plaintext = fh.read()
fh.close()
print(str(plaintext[0:8]), plaintext[0:8].encode("hex"))

fh = open("./secret.pdf.enc2", "rb")
cipher = fh.read()
fh.close()
print(str(cipher[0:8]), cipher[0:8].encode("hex"))

"""

Plaintext:  ('%PDF-1.', '255044462d312e34')
                         255044462d312e00
Mask:                    ffffffffffffff00
Cipher:     761473e789210dc2

f54f429e43206f

"""
