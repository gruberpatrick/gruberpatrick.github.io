
from Crypto.Cipher import DES
import itertools

fh = open("./test.pdf.enc", "rb")
text = fh.read()
fh.close()

space = []

iterator = 20
while str(hex(iterator)) != "0x7f":
    space.append(str(hex(iterator))[2:])
    iterator += 1

gen = itertools.combinations_with_replacement(space, 8)
space = []
for it in gen:
    key = "".join(list(it))

    print "\rHEX-KEY:", key, 
    iterator += 1

    key = (key).decode("hex")
    cipher = DES.new(key, DES.MODE_ECB)
    msg = cipher.decrypt(text)

    if msg[0:8].find("PDF") >= 0:

        print "KEY:", key
        print "HEADER:", msg[0:8]
