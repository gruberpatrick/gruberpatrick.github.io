
from Crypto.Cipher import DES

fh = open("./test.pdf", "rb")
plaintext = fh.read() + "000000"
fh.close()

print(plaintext[0:8].encode("hex"))

key = "f4a6d052e41880de"

print(str(key), key.decode("hex"))
cipher = DES.new(key.decode("hex"), DES.MODE_ECB)
enc = cipher.decrypt(plaintext[0:8])

print(str(enc[0:8]), enc[0:8].encode("hex"))

fh = open("./test_output.pdf", "wb")
fh.write(enc)
fh.close()
